package snakeladder;

import javax.swing.JFrame;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.util.Random;
import java.awt.event.ActionEvent;

public class snakelad extends JFrame 
{
	int sum1=0,sum2=0;
	private JTextField t[]=new JTextField[100];
	private JTextField t100;
	private JTextField t81;
	private JTextField textField_39;
	private JTextField t61;
	
	private JTextField t60;
	private JTextField t41;
	private JTextField textField_57;
	private JTextField t40;
	private JTextField t21;
	private JTextField t20;
	private JTextField t1;
	private JTextField t80;
	private JTextField t99;
	private JTextField t98;
	private JTextField t97;
	private JTextField t96;
	private JTextField t95;
	private JTextField t94;
	private JTextField t93;
	private JTextField t92;
	private JTextField t91;
	private JTextField t82;
	private JTextField t83;
	private JTextField t84;
	private JTextField t85;
	private JTextField t86;
	private JTextField t87;
	private JTextField t88;
	private JTextField t89;
	private JTextField t90;
	private JTextField t62;
	private JTextField t63;
	private JTextField t64;
	private JTextField t65;
	private JTextField t66;
	private JTextField t67;
	private JTextField t68;
	private JTextField t69;
	private JTextField t70;
	private JTextField t42;
	private JTextField t43;
	private JTextField t44;
	private JTextField t45;
	private JTextField t46;
	private JTextField t47;
	private JTextField t48;
	private JTextField t49;
	private JTextField t50;
	private JTextField t22;
	private JTextField t23;
	private JTextField t24;
	private JTextField t25;
	private JTextField t26;
	private JTextField t27;
	private JTextField t28;
	private JTextField t29;
	private JTextField t30;
	private JTextField t2;
	private JTextField t3;
	private JTextField t4;
	private JTextField t5;
	private JTextField t6;
	private JTextField t7;
	private JTextField t8;
	private JTextField t9;
	private JTextField t10;
	private JTextField t79;
	private JTextField t78;
	private JTextField t77;
	private JTextField t76;
	private JTextField t75;
	private JTextField t74;
	private JTextField t73;
	private JTextField t72;
	private JTextField t71;
	private JTextField t59;
	private JTextField t58;
	private JTextField t57;
	private JTextField t56;
	private JTextField t55;
	private JTextField t54;
	private JTextField t53;
	private JTextField t52;
	private JTextField t51;
	private JTextField t39;
	private JTextField t38;
	private JTextField t37;
	private JTextField t36;
	private JTextField t35;
	private JTextField t34;
	private JTextField t33;
	private JTextField t32;
	private JTextField t31;
	private JTextField t19;
	private JTextField t18;
	private JTextField t17;
	private JTextField t16;
	private JTextField t15;
	private JTextField t14;
	private JTextField t13;
	private JTextField t12;
	private JTextField t11;
	private JLabel lblNewLabel;
	private JLabel label;
	private JLabel lblNewLabel_2;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_3;
	private JLabel lblNewLabel_4;
	private JLabel p1;
	private JLabel p2;
	private JLabel lblNewLabel_5;
	private JLabel lblNewLabel_7;
	
	
	public snakelad() {
		getContentPane().setBackground(Color.WHITE);
		getContentPane().setLayout(null);
		
		t100 = new JTextField();
		t100.setForeground(Color.BLACK);
		t100.setBounds(28, 64, 57, 39);
		t100.setText("100");
		t100.setHorizontalAlignment(SwingConstants.CENTER);
		t100.setBackground(Color.WHITE);
		t100.setEditable(false);
		
		t100.setFont(new Font("Times New Roman", Font.BOLD, 18));
		getContentPane().add(t100);
		t100.setColumns(10);
		
		t81 = new JTextField();
		t81.setBounds(28, 103, 57, 39);
		t81.setText("81");
		t81.setHorizontalAlignment(SwingConstants.CENTER);
		t81.setForeground(Color.BLACK);
		t81.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t81.setEditable(false);
		t81.setColumns(10);
		t81.setBackground(Color.BLACK);
		getContentPane().add(t81);
		
		t61 = new JTextField();
		t61.setBounds(28, 179, 57, 39);
		t61.setText("61");
		t61.setHorizontalAlignment(SwingConstants.CENTER);
		t61.setForeground(Color.BLACK);
		t61.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t61.setEditable(false);
		t61.setColumns(10);
		t61.setBackground(Color.BLACK);
		getContentPane().add(t61);
		
		t60 = new JTextField();
		t60.setBounds(28, 218, 57, 39);
		t60.setText("60");
		t60.setHorizontalAlignment(SwingConstants.CENTER);
		t60.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t60.setEditable(false);
		t60.setColumns(10);
		t60.setBackground(Color.WHITE);
		getContentPane().add(t60);
		
		t41 = new JTextField();
		t41.setBounds(28, 257, 57, 39);
		t41.setText("41");
		t41.setHorizontalAlignment(SwingConstants.CENTER);
		t41.setForeground(Color.BLACK);
		t41.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t41.setEditable(false);
		t41.setColumns(10);
		t41.setBackground(Color.BLACK);
		getContentPane().add(t41);
		
		t40 = new JTextField();
		t40.setBounds(28, 296, 57, 39);
		t40.setText("40");
		t40.setHorizontalAlignment(SwingConstants.CENTER);
		t40.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t40.setEditable(false);
		t40.setColumns(10);
		t40.setBackground(Color.WHITE);
		getContentPane().add(t40);
		
		t21 = new JTextField();
		t21.setBounds(28, 335, 57, 39);
		t21.setText("21");
		t21.setHorizontalAlignment(SwingConstants.CENTER);
		t21.setForeground(Color.BLACK);
		t21.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t21.setEditable(false);
		t21.setColumns(10);
		t21.setBackground(Color.BLACK);
		getContentPane().add(t21);
		
		t20 = new JTextField();
		t20.setBounds(28, 374, 57, 39);
		t20.setText("20");
		t20.setHorizontalAlignment(SwingConstants.CENTER);
		t20.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t20.setEditable(false);
		t20.setColumns(10);
		t20.setBackground(Color.WHITE);
		getContentPane().add(t20);
		
		t1 = new JTextField();
		t1.setBounds(28, 413, 57, 39);
		t1.setText("1");
		t1.setHorizontalAlignment(SwingConstants.CENTER);
		t1.setForeground(Color.BLACK);
		t1.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t1.setEditable(false);
		t1.setColumns(10);
		t1.setBackground(Color.BLACK);
		getContentPane().add(t1);
		
		t80 = new JTextField();
		t80.setBounds(28, 142, 57, 39);
		t80.setText("80");
		t80.setHorizontalAlignment(SwingConstants.CENTER);
		t80.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t80.setEditable(false);
		t80.setColumns(10);
		t80.setBackground(Color.WHITE);
		getContentPane().add(t80);
		
		t99 = new JTextField();
		t99.setBounds(84, 64, 57, 39);
		t99.setText("99");
		t99.setHorizontalAlignment(SwingConstants.CENTER);
		t99.setForeground(Color.BLACK);
		t99.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t99.setEditable(false);
		t99.setColumns(10);
		t99.setBackground(Color.BLACK);
		getContentPane().add(t99);
		
		t98 = new JTextField();
		t98.setBounds(141, 64, 57, 39);
		t98.setText("98");
		t98.setHorizontalAlignment(SwingConstants.CENTER);
		t98.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t98.setEditable(false);
		t98.setColumns(10);
		t98.setBackground(Color.WHITE);
		getContentPane().add(t98);
		
		t97 = new JTextField();
		t97.setBounds(197, 64, 57, 39);
		t97.setText("97");
		t97.setHorizontalAlignment(SwingConstants.CENTER);
		t97.setForeground(Color.BLACK);
		t97.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t97.setEditable(false);
		t97.setColumns(10);
		t97.setBackground(Color.BLACK);
		getContentPane().add(t97);
		
		t96 = new JTextField();
		t96.setBounds(252, 64, 57, 39);
		t96.setText("96");
		t96.setHorizontalAlignment(SwingConstants.CENTER);
		t96.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t96.setEditable(false);
		t96.setColumns(10);
		t96.setBackground(Color.WHITE);
		getContentPane().add(t96);
		
		t95 = new JTextField();
		t95.setBounds(308, 64, 57, 39);
		t95.setText("95");
		t95.setHorizontalAlignment(SwingConstants.CENTER);
		t95.setForeground(Color.BLACK);
		t95.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t95.setEditable(false);
		t95.setColumns(10);
		t95.setOpaque(false);
		t95.setBackground(Color.BLACK);
		getContentPane().add(t95);
		
		t94 = new JTextField();
		t94.setBounds(365, 64, 57, 39);
		t94.setText("94");
		t94.setHorizontalAlignment(SwingConstants.CENTER);
		t94.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t94.setEditable(false);
		t94.setColumns(10);
		t94.setBackground(Color.WHITE);
		getContentPane().add(t94);
		
		t93 = new JTextField();
		t93.setBounds(420, 64, 57, 39);
		t93.setText("93");
		t93.setHorizontalAlignment(SwingConstants.CENTER);
		t93.setForeground(Color.BLACK);
		t93.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t93.setEditable(false);
		t93.setColumns(10);
		t93.setBackground(Color.BLACK);
		getContentPane().add(t93);
		
		t92 = new JTextField();
		t92.setBounds(475, 64, 57, 39);
		t92.setText("92");
		t92.setHorizontalAlignment(SwingConstants.CENTER);
		t92.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t92.setEditable(false);
		t92.setColumns(10);
		t92.setBackground(Color.WHITE);
		getContentPane().add(t92);
		
		t91 = new JTextField();
		t91.setBounds(531, 64, 57, 39);
		t91.setText("91");
		t91.setHorizontalAlignment(SwingConstants.CENTER);
		t91.setForeground(Color.BLACK);
		t91.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t91.setEditable(false);
		t91.setColumns(10);
		t91.setBackground(Color.BLACK);
		getContentPane().add(t91);
		
		t82 = new JTextField();
		t82.setBounds(84, 103, 57, 39);
		t82.setText("82");
		t82.setHorizontalAlignment(SwingConstants.CENTER);
		t82.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t82.setEditable(false);
		t82.setColumns(10);
		t82.setBackground(Color.WHITE);
		getContentPane().add(t82);
		
		t83 = new JTextField();
		t83.setBounds(141, 103, 57, 39);
		t83.setText("83");
		t83.setHorizontalAlignment(SwingConstants.CENTER);
		t83.setForeground(Color.BLACK);
		t83.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t83.setEditable(false);
		t83.setColumns(10);
		t83.setBackground(Color.BLACK);
		getContentPane().add(t83);
		
		t84 = new JTextField();
		t84.setBounds(197, 103, 57, 39);
		t84.setText("84");
		t84.setHorizontalAlignment(SwingConstants.CENTER);
		t84.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t84.setEditable(false);
		t84.setColumns(10);
		t84.setBackground(Color.WHITE);
		getContentPane().add(t84);
		
		t85 = new JTextField();
		t85.setBounds(252, 103, 57, 39);
		t85.setText("85");
		t85.setHorizontalAlignment(SwingConstants.CENTER);
		t85.setForeground(Color.BLACK);
		t85.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t85.setEditable(false);
		t85.setColumns(10);
		t85.setBackground(Color.BLACK);
		getContentPane().add(t85);
		
		t86 = new JTextField();
		t86.setBounds(308, 103, 57, 39);
		t86.setText("86");
		t86.setHorizontalAlignment(SwingConstants.CENTER);
		t86.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t86.setEditable(false);
		t86.setColumns(10);
		t86.setBackground(Color.WHITE);
		getContentPane().add(t86);
		
		t87 = new JTextField();
		t87.setBounds(365, 103, 57, 39);
		t87.setText("87");
		t87.setHorizontalAlignment(SwingConstants.CENTER);
		t87.setForeground(Color.BLACK);
		t87.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t87.setEditable(false);
		t87.setColumns(10);
		t87.setBackground(Color.BLACK);
		getContentPane().add(t87);
		
		t88 = new JTextField();
		t88.setBounds(420, 103, 57, 39);
		t88.setText("88");
		t88.setHorizontalAlignment(SwingConstants.CENTER);
		t88.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t88.setEditable(false);
		t88.setColumns(10);
		t88.setBackground(Color.WHITE);
		getContentPane().add(t88);
		
		t89 = new JTextField();
		t89.setBounds(475, 103, 57, 39);
		t89.setText("89");
		t89.setHorizontalAlignment(SwingConstants.CENTER);
		t89.setForeground(Color.BLACK);
		t89.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t89.setEditable(false);
		t89.setColumns(10);
		t89.setBackground(Color.BLACK);
		getContentPane().add(t89);
		
		t90 = new JTextField();
		t90.setBounds(531, 103, 57, 39);
		t90.setText("90");
		t90.setHorizontalAlignment(SwingConstants.CENTER);
		t90.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t90.setEditable(false);
		t90.setColumns(10);
		t90.setBackground(Color.WHITE);
		getContentPane().add(t90);
		
		t62 = new JTextField();
		t62.setBounds(84, 179, 57, 39);
		t62.setText("62");
		t62.setHorizontalAlignment(SwingConstants.CENTER);
		t62.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t62.setEditable(false);
		t62.setColumns(10);
		t62.setBackground(Color.WHITE);
		getContentPane().add(t62);
		
		t63 = new JTextField();
		t63.setBounds(141, 179, 57, 39);
		t63.setText("63");
		t63.setHorizontalAlignment(SwingConstants.CENTER);
		t63.setForeground(Color.BLACK);
		t63.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t63.setEditable(false);
		t63.setColumns(10);
		t63.setBackground(Color.BLACK);
		getContentPane().add(t63);
		
		t64 = new JTextField();
		t64.setBounds(197, 179, 57, 39);
		t64.setText("64");
		t64.setHorizontalAlignment(SwingConstants.CENTER);
		t64.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t64.setEditable(false);
		t64.setColumns(10);
		t64.setBackground(Color.WHITE);
		getContentPane().add(t64);
		
		t65 = new JTextField();
		t65.setBounds(252, 179, 57, 39);
		t65.setText("65");
		t65.setHorizontalAlignment(SwingConstants.CENTER);
		t65.setForeground(Color.BLACK);
		t65.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t65.setEditable(false);
		t65.setColumns(10);
		t65.setBackground(Color.BLACK);
		getContentPane().add(t65);
		
		t66 = new JTextField();
		t66.setBounds(308, 179, 57, 39);
		t66.setText("66");
		t66.setHorizontalAlignment(SwingConstants.CENTER);
		t66.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t66.setEditable(false);
		t66.setColumns(10);
		t66.setBackground(Color.WHITE);
		getContentPane().add(t66);
		
		t67 = new JTextField();
		t67.setBounds(365, 179, 57, 39);
		t67.setText("67");
		t67.setHorizontalAlignment(SwingConstants.CENTER);
		t67.setForeground(Color.BLACK);
		t67.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t67.setEditable(false);
		t67.setColumns(10);
		t67.setBackground(Color.BLACK);
		getContentPane().add(t67);
		
		t68 = new JTextField();
		t68.setBounds(420, 179, 57, 39);
		t68.setText("68");
		t68.setHorizontalAlignment(SwingConstants.CENTER);
		t68.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t68.setEditable(false);
		t68.setColumns(10);
		t68.setBackground(Color.WHITE);
		getContentPane().add(t68);
		
		t69 = new JTextField();
		t69.setBounds(475, 179, 57, 39);
		t69.setText("69");
		t69.setHorizontalAlignment(SwingConstants.CENTER);
		t69.setForeground(Color.BLACK);
		t69.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t69.setEditable(false);
		t69.setColumns(10);
		t69.setBackground(Color.BLACK);
		getContentPane().add(t69);
		
		t70 = new JTextField();
		t70.setBounds(531, 179, 57, 39);
		t70.setText("70");
		t70.setHorizontalAlignment(SwingConstants.CENTER);
		t70.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t70.setEditable(false);
		t70.setColumns(10);
		t70.setBackground(Color.WHITE);
		getContentPane().add(t70);
		
		t42 = new JTextField();
		t42.setBounds(84, 257, 57, 39);
		t42.setText("42");
		t42.setHorizontalAlignment(SwingConstants.CENTER);
		t42.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t42.setEditable(false);
		t42.setColumns(10);
		t42.setBackground(Color.WHITE);
		getContentPane().add(t42);
		
		t43 = new JTextField();
		t43.setBounds(141, 257, 57, 39);
		t43.setText("43");
		t43.setHorizontalAlignment(SwingConstants.CENTER);
		t43.setForeground(Color.BLACK);
		t43.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t43.setEditable(false);
		t43.setColumns(10);
		t43.setBackground(Color.BLACK);
		getContentPane().add(t43);
		
		t44 = new JTextField();
		t44.setBounds(197, 257, 57, 39);
		t44.setText("44");
		t44.setHorizontalAlignment(SwingConstants.CENTER);
		t44.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t44.setEditable(false);
		t44.setColumns(10);
		t44.setBackground(Color.WHITE);
		getContentPane().add(t44);
		
		t45 = new JTextField();
		t45.setBounds(252, 257, 57, 39);
		t45.setText("45");
		t45.setHorizontalAlignment(SwingConstants.CENTER);
		t45.setForeground(Color.BLACK);
		t45.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t45.setEditable(false);
		t45.setColumns(10);
		t45.setBackground(Color.BLACK);
		getContentPane().add(t45);
		
		t46 = new JTextField();
		t46.setBounds(308, 257, 57, 39);
		t46.setText("46");
		t46.setHorizontalAlignment(SwingConstants.CENTER);
		t46.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t46.setEditable(false);
		t46.setColumns(10);
		t46.setBackground(Color.WHITE);
		getContentPane().add(t46);
		
		t47 = new JTextField();
		t47.setBounds(365, 257, 57, 39);
		t47.setText("47");
		t47.setHorizontalAlignment(SwingConstants.CENTER);
		t47.setForeground(Color.BLACK);
		t47.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t47.setEditable(false);
		t47.setColumns(10);
		t47.setBackground(Color.BLACK);
		getContentPane().add(t47);
		
		t48 = new JTextField();
		t48.setBounds(420, 257, 57, 39);
		t48.setText("48");
		t48.setHorizontalAlignment(SwingConstants.CENTER);
		t48.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t48.setEditable(false);
		t48.setColumns(10);
		t48.setBackground(Color.WHITE);
		getContentPane().add(t48);
		
		t49 = new JTextField();
		t49.setBounds(475, 257, 57, 39);
		t49.setText("49");
		t49.setHorizontalAlignment(SwingConstants.CENTER);
		t49.setForeground(Color.BLACK);
		t49.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t49.setEditable(false);
		t49.setColumns(10);
		t49.setBackground(Color.BLACK);
		getContentPane().add(t49);
		
		t50 = new JTextField();
		t50.setBounds(531, 257, 57, 39);
		t50.setText("50");
		t50.setHorizontalAlignment(SwingConstants.CENTER);
		t50.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t50.setEditable(false);
		t50.setColumns(10);
		t50.setBackground(Color.WHITE);
		getContentPane().add(t50);
		
		t22 = new JTextField();
		t22.setBounds(84, 335, 57, 39);
		t22.setText("22");
		t22.setHorizontalAlignment(SwingConstants.CENTER);
		t22.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t22.setEditable(false);
		t22.setColumns(10);
		t22.setBackground(Color.WHITE);
		getContentPane().add(t22);
		
		t23 = new JTextField();
		t23.setBounds(141, 335, 57, 39);
		t23.setText("23");
		t23.setHorizontalAlignment(SwingConstants.CENTER);
		t23.setForeground(Color.BLACK);
		t23.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t23.setEditable(false);
		t23.setColumns(10);
		t23.setBackground(Color.BLACK);
		getContentPane().add(t23);
		
		t24 = new JTextField();
		t24.setBounds(197, 335, 57, 39);
		t24.setText("24");
		t24.setHorizontalAlignment(SwingConstants.CENTER);
		t24.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t24.setEditable(false);
		t24.setColumns(10);
		t24.setBackground(Color.WHITE);
		getContentPane().add(t24);
		
		t25 = new JTextField();
		t25.setBounds(252, 335, 57, 39);
		t25.setText("25");
		t25.setHorizontalAlignment(SwingConstants.CENTER);
		t25.setForeground(Color.BLACK);
		t25.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t25.setEditable(false);
		t25.setColumns(10);
		t25.setBackground(Color.BLACK);
		getContentPane().add(t25);
		
		t26 = new JTextField();
		t26.setBounds(308, 335, 57, 39);
		t26.setText("26");
		t26.setHorizontalAlignment(SwingConstants.CENTER);
		t26.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t26.setEditable(false);
		t26.setColumns(10);
		t26.setBackground(Color.WHITE);
		getContentPane().add(t26);
		
		t27 = new JTextField();
		t27.setBounds(365, 335, 57, 39);
		t27.setText("27");
		t27.setHorizontalAlignment(SwingConstants.CENTER);
		t27.setForeground(Color.BLACK);
		t27.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t27.setEditable(false);
		t27.setColumns(10);
		t27.setBackground(Color.BLACK);
		getContentPane().add(t27);
		
		t28 = new JTextField();
		t28.setBounds(420, 335, 57, 39);
		t28.setText("28");
		t28.setHorizontalAlignment(SwingConstants.CENTER);
		t28.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t28.setEditable(false);
		t28.setColumns(10);
		t28.setBackground(Color.WHITE);
		getContentPane().add(t28);
		
		t29 = new JTextField();
		t29.setBounds(475, 335, 57, 39);
		t29.setText("29");
		t29.setHorizontalAlignment(SwingConstants.CENTER);
		t29.setForeground(Color.BLACK);
		t29.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t29.setEditable(false);
		t29.setColumns(10);
		t29.setBackground(Color.BLACK);
		getContentPane().add(t29);
		
		t30 = new JTextField();
		t30.setBounds(531, 335, 57, 39);
		t30.setText("30");
		t30.setHorizontalAlignment(SwingConstants.CENTER);
		t30.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t30.setEditable(false);
		t30.setColumns(10);
		t30.setBackground(Color.WHITE);
		getContentPane().add(t30);
		
		t2 = new JTextField();
		t2.setBounds(84, 413, 57, 39);
		t2.setText("2");
		t2.setHorizontalAlignment(SwingConstants.CENTER);
		t2.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t2.setEditable(false);
		t2.setColumns(10);
		t2.setBackground(Color.WHITE);
		getContentPane().add(t2);
		
		t3 = new JTextField();
		t3.setBounds(141, 413, 57, 39);
		t3.setText("3");
		t3.setHorizontalAlignment(SwingConstants.CENTER);
		t3.setForeground(Color.BLACK);
		t3.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t3.setEditable(false);
		t3.setColumns(10);
		t3.setBackground(Color.BLACK);
		getContentPane().add(t3);
		
		t4 = new JTextField();
		t4.setBounds(197, 413, 57, 39);
		t4.setText("4");
		t4.setHorizontalAlignment(SwingConstants.CENTER);
		t4.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t4.setEditable(false);
		t4.setColumns(10);
		t4.setBackground(Color.WHITE);
		getContentPane().add(t4);
		
		t5 = new JTextField();
		t5.setBounds(252, 413, 57, 39);
		t5.setText("5");
		t5.setHorizontalAlignment(SwingConstants.CENTER);
		t5.setForeground(Color.BLACK);
		t5.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t5.setEditable(false);
		t5.setColumns(10);
		t5.setBackground(Color.BLACK);
		getContentPane().add(t5);
		
		t6 = new JTextField();
		t6.setBounds(308, 413, 57, 39);
		t6.setText("6");
		t6.setHorizontalAlignment(SwingConstants.CENTER);
		t6.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t6.setEditable(false);
		t6.setColumns(10);
		t6.setBackground(Color.WHITE);
		getContentPane().add(t6);
		
		t7 = new JTextField();
		t7.setBounds(365, 413, 57, 39);
		t7.setText("7");
		t7.setHorizontalAlignment(SwingConstants.CENTER);
		t7.setForeground(Color.BLACK);
		t7.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t7.setEditable(false);
		t7.setColumns(10);
		t7.setBackground(Color.BLACK);
		getContentPane().add(t7);
		
		t8 = new JTextField();
		t8.setBounds(420, 413, 57, 39);
		t8.setText("8");
		t8.setHorizontalAlignment(SwingConstants.CENTER);
		t8.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t8.setEditable(false);
		t8.setColumns(10);
		t8.setBackground(Color.WHITE);
		getContentPane().add(t8);
		
		t9 = new JTextField();
		t9.setBounds(475, 413, 57, 39);
		t9.setText("9");
		t9.setHorizontalAlignment(SwingConstants.CENTER);
		t9.setForeground(Color.BLACK);
		t9.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t9.setEditable(false);
		t9.setColumns(10);
		t9.setBackground(Color.BLACK);
		getContentPane().add(t9);
		
		t10 = new JTextField();
		t10.setBounds(531, 413, 57, 39);
		t10.setText("10");
		t10.setHorizontalAlignment(SwingConstants.CENTER);
		t10.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t10.setEditable(false);
		t10.setColumns(10);
		t10.setBackground(Color.WHITE);
		getContentPane().add(t10);
		
		t79 = new JTextField();
		t79.setBounds(84, 142, 57, 39);
		t79.setText("79");
		t79.setHorizontalAlignment(SwingConstants.CENTER);
		t79.setForeground(Color.BLACK);
		t79.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t79.setEditable(false);
		t79.setColumns(10);
		t79.setBackground(Color.BLACK);
		getContentPane().add(t79);
		
		t78 = new JTextField();
		t78.setBounds(141, 142, 57, 39);
		t78.setText("78");
		t78.setHorizontalAlignment(SwingConstants.CENTER);
		t78.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t78.setEditable(false);
		t78.setColumns(10);
		t78.setBackground(Color.WHITE);
		getContentPane().add(t78);
		
		t77 = new JTextField();
		t77.setBounds(197, 142, 57, 39);
		t77.setText("77");
		t77.setHorizontalAlignment(SwingConstants.CENTER);
		t77.setForeground(Color.BLACK);
		t77.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t77.setEditable(false);
		t77.setColumns(10);
		t77.setBackground(Color.BLACK);
		getContentPane().add(t77);
		
		t76 = new JTextField();
		t76.setBounds(252, 142, 57, 39);
		t76.setText("76");
		t76.setHorizontalAlignment(SwingConstants.CENTER);
		t76.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t76.setEditable(false);
		t76.setColumns(10);
		t76.setBackground(Color.WHITE);
		getContentPane().add(t76);
		
		t75 = new JTextField();
		t75.setBounds(308, 142, 57, 39);
		t75.setText("75");
		t75.setHorizontalAlignment(SwingConstants.CENTER);
		t75.setForeground(Color.BLACK);
		t75.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t75.setEditable(false);
		t75.setColumns(10);
		t75.setBackground(Color.BLACK);
		getContentPane().add(t75);
		
		t74 = new JTextField();
		t74.setBounds(365, 142, 57, 39);
		t74.setText("74");
		t74.setHorizontalAlignment(SwingConstants.CENTER);
		t74.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t74.setEditable(false);
		t74.setColumns(10);
		t74.setBackground(Color.WHITE);
		getContentPane().add(t74);
		
		t73 = new JTextField();
		t73.setBounds(420, 142, 57, 39);
		t73.setText("73");
		t73.setHorizontalAlignment(SwingConstants.CENTER);
		t73.setForeground(Color.BLACK);
		t73.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t73.setEditable(false);
		t73.setColumns(10);
		t73.setBackground(Color.BLACK);
		getContentPane().add(t73);
		
		t72 = new JTextField();
		t72.setBounds(475, 142, 57, 39);
		t72.setText("72");
		t72.setHorizontalAlignment(SwingConstants.CENTER);
		t72.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t72.setEditable(false);
		t72.setColumns(10);
		t72.setBackground(Color.WHITE);
		getContentPane().add(t72);
		
		t71 = new JTextField();
		t71.setBounds(531, 142, 57, 39);
		t71.setText("71");
		t71.setHorizontalAlignment(SwingConstants.CENTER);
		t71.setForeground(Color.BLACK);
		t71.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t71.setEditable(false);
		t71.setColumns(10);
		t71.setBackground(Color.BLACK);
		getContentPane().add(t71);
		
		t59 = new JTextField();
		t59.setBounds(84, 218, 57, 39);
		t59.setText("59");
		t59.setHorizontalAlignment(SwingConstants.CENTER);
		t59.setForeground(Color.BLACK);
		t59.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t59.setEditable(false);
		t59.setColumns(10);
		t59.setBackground(Color.BLACK);
		getContentPane().add(t59);
		
		t58 = new JTextField();
		t58.setBounds(141, 218, 57, 39);
		t58.setText("58");
		t58.setHorizontalAlignment(SwingConstants.CENTER);
		t58.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t58.setEditable(false);
		t58.setColumns(10);
		t58.setBackground(Color.WHITE);
		getContentPane().add(t58);
		
		t57 = new JTextField();
		t57.setBounds(197, 218, 57, 39);
		t57.setText("57");
		t57.setHorizontalAlignment(SwingConstants.CENTER);
		t57.setForeground(Color.BLACK);
		t57.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t57.setEditable(false);
		t57.setColumns(10);
		t57.setBackground(Color.BLACK);
		getContentPane().add(t57);
		
		t56 = new JTextField();
		t56.setBounds(252, 218, 57, 39);
		t56.setText("56");
		t56.setHorizontalAlignment(SwingConstants.CENTER);
		t56.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t56.setEditable(false);
		t56.setColumns(10);
		t56.setBackground(Color.WHITE);
		getContentPane().add(t56);
		
		t55 = new JTextField();
		t55.setBounds(308, 218, 57, 39);
		t55.setText("55");
		t55.setHorizontalAlignment(SwingConstants.CENTER);
		t55.setForeground(Color.BLACK);
		t55.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t55.setEditable(false);
		t55.setColumns(10);
		t55.setBackground(Color.BLACK);
		getContentPane().add(t55);
		
		t54 = new JTextField();
		t54.setBounds(365, 218, 57, 39);
		t54.setText("54");
		t54.setHorizontalAlignment(SwingConstants.CENTER);
		t54.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t54.setEditable(false);
		t54.setColumns(10);
		t54.setBackground(Color.WHITE);
		getContentPane().add(t54);
		
		t53 = new JTextField();
		t53.setBounds(420, 218, 57, 39);
		t53.setText("53");
		t53.setHorizontalAlignment(SwingConstants.CENTER);
		t53.setForeground(Color.BLACK);
		t53.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t53.setEditable(false);
		t53.setColumns(10);
		t53.setBackground(Color.BLACK);
		getContentPane().add(t53);
		
		t52 = new JTextField();
		t52.setBounds(475, 218, 57, 39);
		t52.setText("52");
		t52.setHorizontalAlignment(SwingConstants.CENTER);
		t52.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t52.setEditable(false);
		t52.setColumns(10);
		t52.setBackground(Color.WHITE);
		getContentPane().add(t52);
		
		t51 = new JTextField();
		t51.setBounds(531, 218, 57, 39);
		t51.setText("51");
		t51.setHorizontalAlignment(SwingConstants.CENTER);
		t51.setForeground(Color.BLACK);
		t51.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t51.setEditable(false);
		t51.setColumns(10);
		t51.setBackground(Color.BLACK);
		getContentPane().add(t51);
		
		t39 = new JTextField();
		t39.setBounds(84, 296, 57, 39);
		t39.setText("39");
		t39.setHorizontalAlignment(SwingConstants.CENTER);
		t39.setForeground(Color.BLACK);
		t39.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t39.setEditable(false);
		t39.setColumns(10);
		t39.setBackground(Color.BLACK);
		getContentPane().add(t39);
		
		t38 = new JTextField();
		t38.setBounds(141, 296, 57, 39);
		t38.setText("38");
		t38.setHorizontalAlignment(SwingConstants.CENTER);
		t38.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t38.setEditable(false);
		t38.setColumns(10);
		t38.setBackground(Color.WHITE);
		getContentPane().add(t38);
		
		t37 = new JTextField();
		t37.setBounds(197, 296, 57, 39);
		t37.setText("37");
		t37.setHorizontalAlignment(SwingConstants.CENTER);
		t37.setForeground(Color.BLACK);
		t37.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t37.setEditable(false);
		t37.setColumns(10);
		t37.setBackground(Color.BLACK);
		getContentPane().add(t37);
		
		t36 = new JTextField();
		t36.setBounds(252, 296, 57, 39);
		t36.setText("36");
		t36.setHorizontalAlignment(SwingConstants.CENTER);
		t36.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t36.setEditable(false);
		t36.setColumns(10);
		t36.setBackground(Color.WHITE);
		getContentPane().add(t36);
		
		t35 = new JTextField();
		t35.setBounds(308, 296, 57, 39);
		t35.setText("35");
		t35.setHorizontalAlignment(SwingConstants.CENTER);
		t35.setForeground(Color.BLACK);
		t35.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t35.setEditable(false);
		t35.setColumns(10);
		t35.setBackground(Color.BLACK);
		getContentPane().add(t35);
		
		t34 = new JTextField();
		t34.setBounds(365, 296, 57, 39);
		t34.setText("34");
		t34.setHorizontalAlignment(SwingConstants.CENTER);
		t34.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t34.setEditable(false);
		t34.setColumns(10);
		t34.setBackground(Color.WHITE);
		getContentPane().add(t34);
		
		t33 = new JTextField();
		t33.setBounds(420, 296, 57, 39);
		t33.setText("33");
		t33.setHorizontalAlignment(SwingConstants.CENTER);
		t33.setForeground(Color.BLACK);
		t33.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t33.setEditable(false);
		t33.setColumns(10);
		t33.setBackground(Color.BLACK);
		getContentPane().add(t33);
		
		t32 = new JTextField();
		t32.setBounds(475, 296, 57, 39);
		t32.setText("32");
		t32.setHorizontalAlignment(SwingConstants.CENTER);
		t32.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t32.setEditable(false);
		t32.setColumns(10);
		t32.setBackground(Color.WHITE);
		getContentPane().add(t32);
		
		t31 = new JTextField();
		t31.setBounds(531, 296, 57, 39);
		t31.setText("31");
		t31.setHorizontalAlignment(SwingConstants.CENTER);
		t31.setForeground(Color.BLACK);
		t31.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t31.setEditable(false);
		t31.setColumns(10);
		t31.setBackground(Color.BLACK);
		getContentPane().add(t31);
		
		t19 = new JTextField();
		t19.setBounds(84, 374, 57, 39);
		t19.setText("19");
		t19.setHorizontalAlignment(SwingConstants.CENTER);
		t19.setForeground(Color.BLACK);
		t19.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t19.setEditable(false);
		t19.setColumns(10);
		t19.setBackground(Color.BLACK);
		getContentPane().add(t19);
		
		t18 = new JTextField();
		t18.setBounds(141, 374, 57, 39);
		t18.setText("18");
		t18.setHorizontalAlignment(SwingConstants.CENTER);
		t18.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t18.setEditable(false);
		t18.setColumns(10);
		t18.setBackground(Color.WHITE);
		getContentPane().add(t18);
		
		t17 = new JTextField();
		t17.setBounds(197, 374, 57, 39);
		t17.setText("17");
		t17.setHorizontalAlignment(SwingConstants.CENTER);
		t17.setForeground(Color.BLACK);
		t17.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t17.setEditable(false);
		t17.setColumns(10);
		t17.setBackground(Color.BLACK);
		getContentPane().add(t17);
		
		t16 = new JTextField();
		t16.setBounds(252, 374, 57, 39);
		t16.setText("16");
		t16.setHorizontalAlignment(SwingConstants.CENTER);
		t16.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t16.setEditable(false);
		t16.setColumns(10);
		t16.setBackground(Color.WHITE);
		getContentPane().add(t16);
		
		t15 = new JTextField();
		t15.setBounds(308, 374, 57, 39);
		t15.setText("15");
		t15.setHorizontalAlignment(SwingConstants.CENTER);
		t15.setForeground(Color.BLACK);
		t15.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t15.setEditable(false);
		t15.setColumns(10);
		t15.setBackground(Color.BLACK);
		getContentPane().add(t15);
		
		t14 = new JTextField();
		t14.setBounds(365, 374, 57, 39);
		t14.setText("14");
		t14.setHorizontalAlignment(SwingConstants.CENTER);
		t14.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t14.setEditable(false);
		t14.setColumns(10);
		t14.setBackground(Color.WHITE);
		getContentPane().add(t14);
		
		t13 = new JTextField();
		t13.setBounds(420, 374, 57, 39);
		t13.setText("13");
		t13.setHorizontalAlignment(SwingConstants.CENTER);
		t13.setForeground(Color.BLACK);
		t13.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t13.setEditable(false);
		t13.setColumns(10);
		t13.setBackground(Color.BLACK);
		getContentPane().add(t13);
		
		t12 = new JTextField();
		t12.setBounds(475, 374, 57, 39);
		t12.setText("12");
		t12.setHorizontalAlignment(SwingConstants.CENTER);
		t12.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t12.setEditable(false);
		t12.setColumns(10);
		t12.setBackground(Color.WHITE);
		getContentPane().add(t12);
		
		t11 = new JTextField();
		t11.setBounds(531, 374, 57, 39);
		t11.setText("11");
		t11.setHorizontalAlignment(SwingConstants.CENTER);
		t11.setForeground(Color.BLACK);
		t11.setFont(new Font("Times New Roman", Font.BOLD, 18));
		t11.setEditable(false);
		t11.setColumns(10);
		t11.setBackground(Color.BLACK);
		getContentPane().add(t11);
		
		t100.setOpaque(false);
		t99.setOpaque(false);
		t98.setOpaque(false);
		t97.setOpaque(false);
		t96.setOpaque(false);
		t94.setOpaque(false);
		t93.setOpaque(false);
		t92.setOpaque(false);
		t91.setOpaque(false);
		t90.setOpaque(false);
		t89.setOpaque(false);
		t88.setOpaque(false);
		t87.setOpaque(false);
		t86.setOpaque(false);
		t85.setOpaque(false);
		t84.setOpaque(false);
		t83.setOpaque(false);
		t82.setOpaque(false);
		t81.setOpaque(false);
		t80.setOpaque(false);
		t79.setOpaque(false);
		t78.setOpaque(false);
		t77.setOpaque(false);
		t76.setOpaque(false);
		t75.setOpaque(false);
		t74.setOpaque(false);
		t73.setOpaque(false);
		t72.setOpaque(false);
		t71.setOpaque(false);
		t70.setOpaque(false);
		t69.setOpaque(false);
		t68.setOpaque(false);
		t67.setOpaque(false);
		t66.setOpaque(false);
		t65.setOpaque(false);
		t64.setOpaque(false);
		t63.setOpaque(false);
		t62.setOpaque(false);
		t61.setOpaque(false);
		t60.setOpaque(false);
		t59.setOpaque(false);
		t58.setOpaque(false);
		t57.setOpaque(false);
		t56.setOpaque(false);
		t55.setOpaque(false);
		t54.setOpaque(false);
		t53.setOpaque(false);
		t52.setOpaque(false);
		t51.setOpaque(false);
		t50.setOpaque(false);
		t49.setOpaque(false);
		t48.setOpaque(false);
		t47.setOpaque(false);
		t46.setOpaque(false);
		t45.setOpaque(false);
		t44.setOpaque(false);
		t43.setOpaque(false);
		t42.setOpaque(false);
		t41.setOpaque(false);
		t40.setOpaque(false);
		t39.setOpaque(false);
		t38.setOpaque(false);
		t37.setOpaque(false);
		t36.setOpaque(false);
		t35.setOpaque(false);
		t34.setOpaque(false);
		t33.setOpaque(false);
		t32.setOpaque(false);
		t31.setOpaque(false);
		t30.setOpaque(false);
		t29.setOpaque(false);
		t28.setOpaque(false);
		t27.setOpaque(false);
		t26.setOpaque(false);
		t25.setOpaque(false);
		t24.setOpaque(false);
		t23.setOpaque(false);
		t22.setOpaque(false);
		t21.setOpaque(false);
		t20.setOpaque(false);
		t19.setOpaque(false);
		t18.setOpaque(false);
		t17.setOpaque(false);
		t16.setOpaque(false);
		t15.setOpaque(false);
		t14.setOpaque(false);
		t13.setOpaque(false);
		t12.setOpaque(false);
		t11.setOpaque(false);
		t10.setOpaque(false);
		t9.setOpaque(false);
		t8.setOpaque(false);
		t7.setOpaque(false);
		t6.setOpaque(false);
		t5.setOpaque(false);
		t4.setOpaque(false);
		t3.setOpaque(false);
		t2.setOpaque(false);
		t1.setOpaque(false);
		
		t[0]=t1;
		t[1]=t2;
		t[2]=t3;
		t[3]=t4;
		t[4]=t5;
		t[5]=t6;
		t[6]=t7;
		t[7]=t8;
		t[8]=t9;
		t[9]=t10;
		t[10]=t11;
		t[11]=t12;
		t[12]=t13;
		t[13]=t14;
		t[14]=t15;
		t[15]=t16;
		t[16]=t17;
		t[17]=t18;
		t[18]=t19;
		t[19]=t20;
		t[20]=t21;
		t[21]=t22;
		t[22]=t23;
		t[23]=t24;
		t[24]=t25;
		t[25]=t26;
		t[26]=t27;
		t[27]=t28;
		t[28]=t29;
		t[29]=t30;
		t[30]=t31;
		t[31]=t32;
		t[32]=t33;
		t[33]=t34;
		t[34]=t35;
		t[35]=t36;
		t[36]=t37;
		t[37]=t38;
		t[38]=t39;
		t[39]=t40;
		t[40]=t41;
		t[41]=t42;
		t[42]=t43;
		t[43]=t44;
		t[44]=t45;
		t[45]=t46;
		t[46]=t47;
		t[47]=t48;
		t[48]=t49;
		t[49]=t50;
		t[50]=t51;
		t[51]=t52;
		t[52]=t53;
		t[53]=t54;
		t[54]=t55;
		t[55]=t56;
		t[56]=t57;
		t[57]=t58;
		t[58]=t59;
		t[59]=t60;
		t[60]=t61;
		t[61]=t62;
		t[62]=t63;
		t[63]=t64;
		t[64]=t65;
		t[65]=t66;
		t[66]=t67;
		t[67]=t68;
		t[68]=t69;
		t[69]=t70;
		t[70]=t71;
		t[71]=t72;
		t[72]=t73;
		t[73]=t74;
		t[74]=t75;
		t[75]=t76;
		t[76]=t77;
		t[77]=t78;
		t[78]=t79;
		t[79]=t80;
		t[80]=t81;
		t[81]=t82;
		t[82]=t83;
		t[83]=t84;
		t[84]=t85;
		t[85]=t86;
		t[86]=t87;
		t[87]=t88;
		t[88]=t89;
		t[89]=t90;
		t[90]=t91;
		t[91]=t92;
		t[92]=t93;
		t[93]=t94;
		t[94]=t95;
		t[95]=t96;
		t[96]=t97;
		t[97]=t98;
		t[98]=t99;
		t[99]=t100;
		
		
		lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(snakelad.class.getResource("/snakeladder/snake.jpg")));
		lblNewLabel.setBounds(58, 279, 277, 173);
		getContentPane().add(lblNewLabel);
		
		label = new JLabel("");
		label.setIcon(new ImageIcon(snakelad.class.getResource("/snakeladder/snake.jpg")));
		label.setBounds(319, 41, 292, 173);
		getContentPane().add(label);
		
		lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setIcon(new ImageIcon(snakelad.class.getResource("/snakeladder/ladder.png")));
		lblNewLabel_2.setBounds(365, 229, 196, 212);
		getContentPane().add(lblNewLabel_2);
		
		lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setIcon(new ImageIcon(snakelad.class.getResource("/snakeladder/ladder.png")));
		lblNewLabel_1.setBounds(-26, 68, 181, 217);
		getContentPane().add(lblNewLabel_1);
		
		lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(snakelad.class.getResource("/snakeladder/snake5.jpg")));
		lblNewLabel_3.setBounds(129, 114, 169, 143);
		getContentPane().add(lblNewLabel_3);
		
		lblNewLabel_4 = new JLabel("SNAKE AND LADDER GAME");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Times New Roman", Font.BOLD, 24));
		lblNewLabel_4.setBounds(139, 11, 338, 28);
		getContentPane().add(lblNewLabel_4);
		
		JButton btnNewButton = new JButton("Player 1");
		JButton btnPlayer = new JButton("Player 2");
		JLabel dice = new JLabel("0");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) 
			{
				int temp;
				Random r= new Random();
				int n=r.nextInt(7);
				if(n!=0)
				{
					dice.setText(String.valueOf(n));
				}
				else
				{
					n=n+1;
					dice.setText(String.valueOf(1));
				}
				
				if(sum1!=0)
				{
					temp=sum1;
					sum1+=n;
					if(sum1<=100)
					{
						
						t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
						t[temp-1].setText(String.valueOf(temp));
						p1.setText(String.valueOf(sum1));
						if(sum1==100)
						{
							JFrame f=new JFrame();
							JOptionPane.showMessageDialog(f, "Player 1 wins");
							System.exit(0);
						}
						if(sum1==8)
						{
							temp=sum1;
							sum1=52;
							t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
							t[temp-1].setText(String.valueOf(temp));
							p1.setText(String.valueOf(sum1));
						}
						else if(sum1==41)
						{
							temp=sum1;
							sum1=99;
							t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
							t[temp-1].setText(String.valueOf(temp));
							p1.setText(String.valueOf(sum1));
						}
						else if(sum1==36)
						{
							temp=sum1;
							sum1=20;
							t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
							t[temp-1].setText(String.valueOf(temp));
							p1.setText(String.valueOf(sum1));
						}
						else if(sum1==78)
						{
							temp=sum1;
							sum1=65;
							t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
							t[temp-1].setText(String.valueOf(temp));
							p1.setText(String.valueOf(sum1));
						}
						else if(sum1==91)
						{
							temp=sum1;
							sum1=75;
							t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
							t[temp-1].setText(String.valueOf(temp));
							p1.setText(String.valueOf(sum1));
						}
					}
					else
					{
						sum1=temp;
						p1.setText(String.valueOf(sum1));
					}
				}
				else
				{
					sum1+=n;
					t[sum1-1].setText(t[sum1-1].getText().toString()+"\n "+"P1");
					p1.setText(String.valueOf(sum1));
				}
				
				btnNewButton.setEnabled(false);
				btnPlayer.setEnabled(true);
			}
		});
		btnNewButton.setBounds(154, 479, 89, 34);
		getContentPane().add(btnNewButton);
		
		
		btnPlayer.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) 
			{
				int temp;
				Random r= new Random();
				int n=r.nextInt(7);
				if(n!=0)
				{
					dice.setText(String.valueOf(n));
				}
				else
				{
					n=n+1;
					dice.setText(String.valueOf(1));
				}
				if(sum2!=0)
				{
					temp=sum2;
					sum2+=n;
					if(sum2<=100)
					{
						
						
						
						t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
						t[temp-1].setText(String.valueOf(temp));
						p2.setText(String.valueOf(sum2));
						if(sum2==100)
						{
							JFrame f=new JFrame();
							JOptionPane.showMessageDialog(f, "Player 2 wins");
							System.exit(0);
						}
						if(sum2==8)
						{
							temp=sum2;
							sum2=52;
							t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
							t[temp-1].setText(String.valueOf(temp));
							p2.setText(String.valueOf(sum2));
						}
						else if(sum2==41)
						{
							temp=sum2;
							sum2=99;
							t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
							t[temp-1].setText(String.valueOf(temp));
							p2.setText(String.valueOf(sum2));
						}
						else if(sum2==36)
						{
							temp=sum2;
							sum2=20;
							t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
							t[temp-1].setText(String.valueOf(temp));
							p2.setText(String.valueOf(sum2));
						}
						else if(sum2==78)
						{
							temp=sum2;
							sum2=65;
							t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
							t[temp-1].setText(String.valueOf(temp));
							p2.setText(String.valueOf(sum2));
						}
						else if(sum2==91)
						{
							temp=sum2;
							sum2=75;
							t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
							t[temp-1].setText(String.valueOf(temp));
							p2.setText(String.valueOf(sum2));
						}
					}
					else
					{
						sum2=temp;
						p2.setText(String.valueOf(sum2));
					}
				}
				else
				{
					sum2+=n;
					t[sum2-1].setText(t[sum2-1].getText().toString()+"\n "+"P2");
					p2.setText(String.valueOf(sum2));
				}
				btnNewButton.setEnabled(true);
				btnPlayer.setEnabled(false);
			}
		});
		btnPlayer.setBounds(374, 479, 89, 34);
		getContentPane().add(btnPlayer);
		
		
		dice.setHorizontalAlignment(SwingConstants.CENTER);
		dice.setFont(new Font("Times New Roman", Font.BOLD, 18));
		dice.setBounds(289, 482, 46, 24);
		getContentPane().add(dice);
		
		JLabel lblNewLabel_6 = new JLabel("P1");
		lblNewLabel_6.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_6.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblNewLabel_6.setBounds(176, 536, 46, 24);
		getContentPane().add(lblNewLabel_6);
		
		JLabel lblP = new JLabel("P2");
		lblP.setHorizontalAlignment(SwingConstants.CENTER);
		lblP.setFont(new Font("Times New Roman", Font.BOLD, 18));
		lblP.setBounds(399, 536, 46, 24);
		getContentPane().add(lblP);
		
		p1 = new JLabel("0");
		p1.setHorizontalAlignment(SwingConstants.CENTER);
		p1.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		p1.setBounds(176, 574, 46, 14);
		getContentPane().add(p1);
		
		p2 = new JLabel("0");
		p2.setFont(new Font("Times New Roman", Font.PLAIN, 16));
		p2.setHorizontalAlignment(SwingConstants.CENTER);
		p2.setBounds(399, 574, 46, 14);
		getContentPane().add(p2);
		
		lblNewLabel_5 = new JLabel("POSITION");
		lblNewLabel_5.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setBounds(28, 574, 79, 14);
		getContentPane().add(lblNewLabel_5);
		
		lblNewLabel_7 = new JLabel("SYMBOL");
		lblNewLabel_7.setFont(new Font("Times New Roman", Font.BOLD, 16));
		lblNewLabel_7.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_7.setBounds(28, 541, 73, 14);
		getContentPane().add(lblNewLabel_7);
		
	}
	public static void main(String [] args)
	{
		snakelad s=new snakelad();
		s.setSize(636,655);
		s.setVisible(true);
	}
}
